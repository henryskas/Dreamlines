<?php
/**
 * The template for displaying content page.
 
 *
 * @package dreamlines
 */         
?>                   
          <div class="section-header">
          <h2 class="text_title_color"><?php the_title(); ?></h2>
          
          
          </div>
          
          <?php if(has_post_thumbnail()) : ?>
		  <div class="customuzepage-item">
			 <?php the_post_thumbnail('news-thumb-large', array('class'    => 'customuzepage-img')); ?>
		  </div>
	     <?php endif; ?>
         
         <p>
						    <?php the_content(); ?>
                            
         </p>
         
         <p>
         <?php if(the_tags()): ?>
                    <?php if (function_exists('the_tags')) { ?><strong>Tags: </strong><?php the_tags('', ', ', ''); ?><br /><?php } ?>
         <?php endif; ?>
         </p>
         
         