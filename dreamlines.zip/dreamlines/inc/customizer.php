<?php
/**
 * dreamlines Theme Customizer
 *
 * @package dreamlines
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * 
 */
function dreamlines_customize_register($wp_customize){

    //--- Social Section ---//
    $wp_customize->add_section('social', array(
     'title'          => __('Social Media', 'dreamlines'),
     'description'    => sprintf( __('Social media urls', 'dreamlines')
     ),
     'priority'       =>140,
    ));

    // Facebook URL Setting
    $wp_customize->add_setting('facebook_url', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Facebook URL Control
    $wp_customize->add_control( 'facebook_url', array(
    'label'    => __('Facebook URL', 'dreamlines'),
    'section'  => 'social',
    'priority' => 1,
    ));

    // Twitter URL Setting
    $wp_customize->add_setting('twitter_url', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Twitter URL Control
    $wp_customize->add_control( 'twitter_url', array(
    'label'    => __('Twitter URL', 'dreamlines'),
    'section'  => 'social',
    'priority' =>2,
    ));

    // Linkedin URL Setting
    $wp_customize->add_setting('linkedin_url', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Linkedin URL Control
    $wp_customize->add_control( 'linkedin_url', array(
    'label'    => __('LinkedIn URL', 'dreamlines'),
    'section'  => 'social',
    'priority' =>2,
    ));

    // instagram URL Setlinkedin_urlting
    $wp_customize->add_setting('instagram_url', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Linkedin URL Control
    $wp_customize->add_control( 'instagram_url', array(
    'label'    => __('Instagram_url URL', 'dreamlines'),
    'section'  => 'social',
    'priority' =>4,
    ));
    //--- Social Section end ---//
    /**/
    // Showcase Section
    $wp_customize->add_section('showcase', array(
        'title'          => __('Showcase', 'dreamlines'),
        'description'    => sprintf( __('Options for showcase area', 'dreamlines')
        ),
        'priority'       => 130,
    ));

    // Image Setting
    $wp_customize->add_setting('showcase_image', array(
    'default' => esc_url( get_template_directory_uri()).'/img/intro-carousel/1.jpg',
    'type'    => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    // Image Control
    $wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'dreamlines', array(
     'label'    => __('Background Image', 'dreamlines'),
     'section'  => 'showcase',
     'settings' => 'showcase_image',
     'priority' => 1,
    )));
    /**/

    //--- General setting text ---//
    $wp_customize->add_section('GeneralSettingtext', array(
     'title'          => __('General Setting text', 'dreamlines'),
     'description'    => sprintf( __('General Setting text theme', 'dreamlines')
     ),
     'priority'       =>150,
    ));
    // Phone number Setting
    $wp_customize->add_setting('Phone_number', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Phone number Control
    $wp_customize->add_control( 'Phone_number', array(
    'label'    => __('Phone number', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 1,
    ));
    // Copyright Setting
    $wp_customize->add_setting('Copyright', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Copyright Control
    $wp_customize->add_control( 'Copyright', array(
    'label'    => __('Company brand', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 1,
    ));
    // Get Start Setting
    $wp_customize->add_setting('GetStart', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Services Control
    $wp_customize->add_control( 'GetStart', array(
    'label'    => __('GetStart ', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 1,
    ));
    // Get Start Setting
    $wp_customize->add_setting('Services', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    // Get Start Control 
    $wp_customize->add_control( 'Services', array(
    'label'    => __('Services ', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 1,
    ));
    // Call action title Setting
    $wp_customize->add_setting('Callaction', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    // Call action title Control 
    $wp_customize->add_control( 'Callaction', array(
    'label'    => __('Call Action ', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 2,
    ));
    // Call action text Setting
    $wp_customize->add_setting('Callaction_text', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    // Call action text Control 
    $wp_customize->add_control( 'Callaction_text', array(
    'label'    => __('Call Action Text', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 2,
    ));
    // Recent news Heading Setting
    $wp_customize->add_setting('recent_news', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    // Recent news Heading Control 
    $wp_customize->add_control( 'recent_news', array(
    'label'    => __('Section news', 'dreamlines'),
    'section'  => 'GeneralSettingtext',
    'priority' => 2,
    ));

    //--- General setting text end ---//

    //--- Customize color ---//
    // text color
    $wp_customize->add_setting( 'text_color', array(
    'default'   => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'text_color', array(
    'section' => 'colors',
    'label'   => esc_html__( 'Text color', 'dreamlines' ),
    ) ) );

    // text title color
    $wp_customize->add_setting( 'text_title_color', array(
    'default'   => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'text_title_color', array(
    'section' => 'colors',
    'label'   => esc_html__( 'Text title color', 'dreamlines' ),
    ) ) );

    // Link color
    $wp_customize->add_setting( 'link_color', array(
    'default'   => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_color', array(
    'section' => 'colors',
    'label'   => esc_html__( 'Link color', 'dreamlines' ),
    ) ) );

    // Accent color
    $wp_customize->add_setting( 'accent_color', array(
    'default'   => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'accent_color', array(
    'section' => 'colors',
    'label'   => esc_html__( 'Accent color', 'dreamlines' ),
    ) ) );
    // Background call action and footer
    $wp_customize->add_setting( 'Background_call_footer', array(
    'default'   => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'Background_call_footer', array(
    'section' => 'colors',
    'label'   => esc_html__( 'background call footer', 'dreamlines' ),
    ) ) );

    // Background theme
    $wp_customize->add_setting( 'Background_theme', array(
    'default'   => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'Background_theme', array(
    'section' => 'colors',
    'label'   => esc_html__( 'Background theme', 'dreamlines' ),
    ) ) );

    //--- Customize color end---//

    //--- Services Section ---//
    $wp_customize->add_section('Services_Section', array(
     'title'          => __('Services Section', 'dreamlines'),
     'description'    => sprintf( __('Services Section', 'dreamlines')
     ),
     'priority'       =>140,
    ));
    // Box Section description Text Setting
    $wp_customize->add_setting( 'box_description', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box  Section description Text Control
    $wp_customize->add_control( 'box_description', array(
    'label'    => __('Description Services', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
    // Box Service 1 Icon Setting
    $wp_customize->add_setting( 'box1_icon', array(
     'default'              => null,
     'type'                 => 'theme_mod',
         'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Service 1 Icon Control
    $wp_customize->add_control( 'box1_icon', array(
     'label'    => __('Box Service 1 Icon', 'dreamlines'),
     'section'  => 'Services_Section',
     'priority' => 20,
    ));
    // Box Section 1 Heading Setting
    $wp_customize->add_setting( 'box1_heading', array(
    'default'   => null,
    'type'      => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Section 1 Heading Control
    $wp_customize->add_control( 'box1_heading', array(
    'label'    => __('Box Section 1 Heading', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
    // Box Section 1 Text Setting
    $wp_customize->add_setting( 'box1_text', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box  Section 1 Text Control
    $wp_customize->add_control( 'box1_text', array(
    'label'    => __('Box Section 1 Text', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
        // Box Service 2 Icon Setting
    $wp_customize->add_setting( 'box2_icon', array(
     'default'              => null,
     'type'                 => 'theme_mod',
         'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Service 2 Icon Control
    $wp_customize->add_control( 'box2_icon', array(
     'label'    => __('Box Service 2 Icon', 'dreamlines'),
     'section'  => 'Services_Section',
     'priority' => 20,
    ));
    // Box Section 2 Heading Setting
    $wp_customize->add_setting( 'box2_heading', array(
    'default'   => null,
    'type'      => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Section 2 Heading Control
    $wp_customize->add_control( 'box2_heading', array(
    'label'    => __('Box Section 2 Heading', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
    // Box Section 2 Text Setting
    $wp_customize->add_setting( 'box2_text', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box  Section 2 Text Control
    $wp_customize->add_control( 'box2_text', array(
    'label'    => __('Box Section 2 Text', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
        // Box Service 3 Icon Setting
    $wp_customize->add_setting( 'box3_icon', array(
     'default'              => null,
     'type'                 => 'theme_mod',
         'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Service 3 Icon Control
    $wp_customize->add_control( 'box3_icon', array(
     'label'    => __('Box Service 3 Icon', 'dreamlines'),
     'section'  => 'Services_Section',
     'priority' => 20,
    ));
    // Box Section 3 Heading Setting
    $wp_customize->add_setting( 'box3_heading', array(
    'default'   => null,
    'type'      => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Section 3 Heading Control
    $wp_customize->add_control( 'box3_heading', array(
    'label'    => __('Box Section 3 Heading', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
    // Box Section 3 Text Setting
    $wp_customize->add_setting( 'box3_text', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box  Section 3 Text Control
    $wp_customize->add_control( 'box3_text', array(
    'label'    => __('Box Section 3 Text', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
    // Box Service 4 Icon Setting
    $wp_customize->add_setting( 'box4_icon', array(
     'default'              => null,
     'type'                 => 'theme_mod',
         'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Service 4 Icon Control
    $wp_customize->add_control( 'box4_icon', array(
     'label'    => __('Box Service 4 Icon', 'dreamlines'),
     'section'  => 'Services_Section',
     'priority' => 20,
    ));
    // Box Section 4 Heading Setting
    $wp_customize->add_setting( 'box4_heading', array(
    'default'   => null,
    'type'      => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Section 4 Heading Control
    $wp_customize->add_control( 'box4_heading', array(
    'label'    => __('Box Section 4 Heading', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));
    // Box Section 4 Text Setting
    $wp_customize->add_setting( 'box4_text', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box  Section 4 Text Control
    $wp_customize->add_control( 'box4_text', array(
    'label'    => __('Box Section 4 Text', 'dreamlines'),
    'section'  => 'Services_Section',
    'priority' => 20,
    ));


    //--- Services Section end---//
    //--- Contact us Section ---//
    $wp_customize->add_section('Contact_us', array(
     'title'          => __('Contact us Section', 'dreamlines'),
     'description'    => sprintf( __('Contact us Section', 'dreamlines')
     ),
     'priority'       =>140,
    ));
    // Box Contact us title Setting
    $wp_customize->add_setting( 'box_heading_Contact_us', array(
    'default'   => null,
    'type'      => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    // Box Contact us title Control
    $wp_customize->add_control( 'box_heading_Contact_us', array(
    'label'    => __('Contact Us Title', 'dreamlines'),
    'section'  => 'Contact_us',
    'priority' => 20,
    ));
    // Box Contact us Text Setting
    $wp_customize->add_setting( 'box_text_Contact_us', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    //  Box Contact us Text Control
    $wp_customize->add_control( 'box_text_Contact_us', array(
    'label'    => __('Box Contact us Text', 'dreamlines'),
    'section'  => 'Contact_us',
    'priority' => 20,
    ));
    // Box Adress Setting
    $wp_customize->add_setting( 'adress', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    //  Box Adress Text Control
    $wp_customize->add_control( 'adress', array(
    'label'    => __('Adress', 'dreamlines'),
    'section'  => 'Contact_us',
    'priority' => 20,
    ));
    // Box Phone Number Setting
    $wp_customize->add_setting( 'phonenumber', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    //  Box Adress Text Control
    $wp_customize->add_control( 'phonenumber', array(
    'label'    => __('Phone Number', 'dreamlines'),
    'section'  => 'Contact_us',
    'priority' => 20,
    ));
    // Box Map Location Setting
    $wp_customize->add_setting( 'map_location', array(
    'default'              => null,
    'type'                 => 'theme_mod',
    'sanitize_callback' => 'sanitize_text_field'
    ));

    //  Box Map Location Control
    $wp_customize->add_control( 'map_location', array(
    'label'    => __('Map Location', 'dreamlines'),
    'section'  => 'Contact_us',
    'priority' => 20,
    ));

    //--- Contact us Section end---//

}

    add_action('customize_register','dreamlines_customize_register');

    //widgets
function dreamlines_widgets_init(){
    //--- Get start front page widgets ---//
    register_sidebar( array(
    'name'          		=> esc_html__( 'Sidebar widgets about img', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-abimg',
    'romana_description'   	=> esc_html__( 'Add widgets here to appear in your sidebar.', 'dreamlines' ),
    'before_widget'	        => '<div class="col-lg-6 about-img">',
    'after_widget'	        => '</div>',
    //'before_title'  		=> '<h3 class="widget-title">',
    //'after_title'   		=> '</h3>',
    ) );

    register_sidebar( array(
    'name'          		=> esc_html__( 'Sidebar About us', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-desc',
    'romana_description'   	=> esc_html__( 'Add widgets here to appear in your sidebar.', 'dreamlines' ),
    'before_widget'	=> '<div class="col-lg-6 content">',
    'after_widget'	=> '</div>',
    'before_title'  		=> '<h2 class="text_title_color">',
    'after_title'   		=> '</h2>',
    ) );

    register_sidebar( array(
    'name'          		=> esc_html__( 'Sodebar Contact form', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-contact_form',
    'romana_description'   	=> esc_html__( 'Contact Form.', 'dreamlines' ),
    'before_widget'	=> '<div class="form">',
    'after_widget'	=> '</div>',
    ) );

    //--- Get start front page widgets end---//

    //--- Footer widgets ---//
    register_sidebar( array(
    'name'          		=> esc_html__( 'Sidebar widgets footer-info', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-footer-info',
    'romana_description'   	=> esc_html__( 'Add widgets here to appear in your sidebar.', 'dreamlines' ),
    'before_widget'	=> '<div class="col-lg-3 col-md-6 footer-info">',
    'after_widget'	=> '</div>',
    'before_title'  		=> '<h3 class="widget-title">',
    'after_title'   		=> '</h3>',
    ) );
    register_sidebar( array(
    'name'          		=> esc_html__( 'Sidebar widgets footer-links', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-footer-links',
    'romana_description'   	=> esc_html__( 'Add widgets here to appear in your sidebar.', 'dreamlines' ),
    'before_widget'	=> '<div class="col-lg-3 col-md-6 footer-links">',
    'after_widget'	=> '</div>',
    'before_title'  		=> '<h4 class="widget-title">',
    'after_title'   		=> '</h4>',
    ) );
    register_sidebar( array(
    'name'          		=> esc_html__( 'Sidebar widgets footer-contact', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-footer-contact',
    'romana_description'   	=> esc_html__( 'Add widgets here to appear in your sidebar.', 'dreamlines' ),
    'before_widget'	=> '<div>',
    'after_widget'	=> '</div>',
    'before_title'  		=> '<h4 class="widget-title">',
    'after_title'   		=> '</h4>',
    ) );

    register_sidebar( array(
    'name'          		=> esc_html__( 'Sidebar widgets footer-newsletter', 'dreamlines' ),
    'id'            		=> 'sidebar-widgets-footer-newsletter',
    'romana_description'   	=> esc_html__( 'Add widgets here to appear in your sidebar.', 'dreamlines' ),
    'before_widget'	=> '<div class="col-lg-3 col-md-6 footer-newsletter">',
    'after_widget'	=> '</div>',
    'before_title'  		=> '<h4 class="widget-title">',
    'after_title'   		=> '</h4>',
    ) );
    //--- Footer widgets end ---//

}

    add_action( 'widgets_init', 'dreamlines_widgets_init');

    // customize css function
function dreamlines_get_customizer_css() {
    ob_start();
    // text color
    $text_color = get_theme_mod( 'text_color', '' );
    $color_default = '#001955';
    if ( ! empty( $text_color ) ) {
    ?>
    body {
    color: <?php echo esc_html($text_color); ?>;
}

    <?php
    }else{?>
    body {
    color: <?php echo esc_html($color_default); ?>;
    } 
    <?php
    }
    // text title color
    $text_title_color = get_theme_mod( 'text_title_color', '');
    if ( ! empty( $text_title_color ) ) {
    ?>
    .text_title_color{
    color: <?php echo esc_html($text_title_color); ?>;
    }

    <?php
    }else{?>
    .text_title_color{
    color: <?php echo esc_html($color_default); ?>;
    }
    <?php
    }

    // Link Color
    $link_color = get_theme_mod( 'link_color', '' );
    $link_color_default = '#e78402';
    if ( ! empty( $link_color ) ) {
    ?>
    a {
    color: <?php echo esc_html($link_color); ?>;
    }
    /* Tagline */
    #header #logo h1 a span{
    color: <?php echo esc_html($link_color); ?>;
    }
    /* menu */
    .nav-menu li:hover > a,
    .nav-menu .menu-active > a {
    color: <?php echo esc_html($link_color); ?>;
    }
    <?php
    }else{?>
    /* Default Color */ 
    a {
    color: <?php echo esc_html($link_color_default); ?>;
    } 
    /* Tagline */
    #header #logo h1 a span{
    color: <?php echo esc_html($link_color_default); ?>;
    }

    <?php 
    } 
    // Background Call action and footer menu
    $Background_call_footer = get_theme_mod( 'Background_call_footer', '' );
    $Background_call_footer_default = '#081e5b';
    if ( ! empty( $Background_call_footer ) ) {
    ?>
    .bgcolour {
    background: <?php echo esc_html($Background_call_footer); ?>;
    }

    <?php
    }else{?>
    /* Default Color */ 
    .bgcolour {
    background: <?php echo esc_html($Background_call_footer_default); ?>;
    } 

    <?php 
    }
    // Background theme
    $Background_theme = get_theme_mod( 'Background_theme', '' );
    $Background_theme_default = '#fff';
    if ( ! empty($Background_theme )) {
    ?>
    body{
    background-color: <?php echo esc_html($Background_theme); ?>;
    }

    <?php
    }else{?>
    /* Default Color */ 
    body{
    background: <?php echo esc_html($Background_theme_default); ?>;
    } 

    <?php 
    }

    // link hover color
    $accent_color = get_theme_mod( 'accent_color', '' );
    $accent_color_default = '#e78402';
    if ( ! empty( $accent_color ) ) {
    ?>
    a:hover {
    color: <?php echo esc_html($accent_color); ?>;
    border-bottom-color: <?php echo esc_html($accent_color); ?>;
    }

    /* menu hover */
    .nav-menu li:hover > a,
    .nav-menu .menu-active > a {
    color: <?php echo esc_html($accent_color); ?>;
    }
    <?php
    }else{?>
    /*Default a:hover*/
    /* menu hover */
    .nav-menu li:hover > a,
    .nav-menu .menu-active > a {
    color: <?php echo esc_html($accent_color_default); ?>;
    }
    <?php 
    }

    $css = ob_get_clean();
    return $css;
}

    // enqueue styles
function dreamlines_enqueue_styles() {
    wp_enqueue_style("theme-styles",get_template_directory_uri()."/css/custom_script.css");
    $custom_css = dreamlines_get_customizer_css();
    wp_add_inline_style( 'theme-styles', $custom_css );
}

    add_action( 'wp_enqueue_scripts', 'dreamlines_enqueue_styles' );