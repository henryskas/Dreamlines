<?php
/**
 * The template for displaying single post.
 */         
?>                   
          
 <div class="section-header">
          <h2 class="text_title_color"><?php the_title(); ?></h2>
          
          <p>
               Posted at 
	           <?php the_time('F j, Y g:i a'); ?>
	           by 
	           <a href="<?php //echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
	           <?php the_author(); ?>
	           </a>  
	          
	           <?php 
			  /* echo  "|Posted In ";
		       $dreamlines_categories = get_the_category();
		       $dreamlines_separator = ", ";
		       $dreamlines_output = '';

		       if($dreamlines_categories){
			      foreach($dreamlines_categories as $dreamlines_category){
				    $dreamlines_output .= '<a href="'.get_category_link($dreamlines_category->term_id).'">'.$dreamlines_category->cat_name.'</a>'. $dreamlines_separator;
			    }
		       }

		        echo trim($dreamlines_output, $dreamlines_separator);*/
	           ?>
          </p>
          
          </div>
          
          <?php if(has_post_thumbnail()) : ?>
		  <div class="customuzepage-item">
			 <?php the_post_thumbnail('news-thumb-large', array('class'    => 'customuzepage-img')); ?>
		  </div>
	     <?php endif; ?>
         
         <p>
						    <?php the_content(); 
							
							wp_link_pages(
							array(
								'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'dreamlines' ) . '</span>',
								'after'       => '</div>',
								'link_before' => '<span>',
								'link_after'  => '</span>',
								'pagelink'    => '<span class="">' . __( 'Page', 'dreamlines' ) . ' </span>%',
								'separator'   => '<span class="">, </span>',
							)
						);
							
							?>
                            
         </p>
         
         <p>
         <?php if(the_tags()): ?>
                    <?php if (function_exists('the_tags')) { ?><strong>Tags: </strong><?php the_tags('', ', ', ''); ?><br /><?php } ?>
         <?php endif; ?>
         </p>
         
         <div class="">
         <a class="button" href="<?php echo esc_url(site_url()); ?>">Go back</a>
         </div>