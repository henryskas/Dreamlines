<?php get_header();?>
<!--========================== Single post ============================-->

     <section id="customuzepage" class="wow fadeInUp">
      <div class="container" >
      
      <?php if(have_posts()) : ?>
          <?php while(have_posts()) : the_post(); ?>
           <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <?php get_template_part('content', get_post_format()); ?>
           </div>
          <?php endwhile; ?>
        <?php endif; ?>
       <?php comments_template(); ?>
      </div>
   </section><!-- End testimonials -->
  
<!-- #Single post -->
  
  <main id="main">
    
<?php get_footer();?>