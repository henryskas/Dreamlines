<?php /**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package dreamlines
 */
?>
<?php get_header();?>
<!--========================== Page ============================-->

     <section id="customuzepage" class="wow fadeInUp">
      <div class="container">
      
        <?php if(have_posts()) : ?>
          <?php while(have_posts()) : the_post(); ?>
            <?php get_template_part('content-page', get_post_format()); ?>
      
          <?php endwhile; ?>
        <?php endif; ?>
   
      </div>
   </section><!-- End testimonials -->
  
<!-- #Page -->
  
  <main id="main">
    
<?php get_footer();?>