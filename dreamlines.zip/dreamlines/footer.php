<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package dreamlines
 */
?>

<!--========================== Call To Action Section ============================-->
<?php if(get_theme_mod('Callaction', 'Call action') != '') : ?>
    <section id="call-to-action" class="wow fadeInUp bgcolour">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-left">
            <h3 class="cta-title"> <?php echo esc_html(get_theme_mod('Callaction','Call action')); ?></h3>
            <p class="cta-text"><?php echo esc_html(get_theme_mod('Callaction_text','Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.')); ?></p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#"><?php echo esc_html(get_theme_mod('Callaction','Call action')); ?></a>
          </div>
        </div>

      </div>
    </section><!-- call-to-action -->
 <?php endif; ?>
    <!--========================== Contact Section ============================-->
    <section id="contact" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2 class="text_title_color"><?php echo esc_html(get_theme_mod('box_heading_Contact_us','Contact us')); ?></h2>
          <p><?php echo esc_html(get_theme_mod('box_text_Contact_us','K Maecenas sed diam eget risus varius blandit sit amet non magna.')); ?></p>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Address</h3>
              <address><?php echo esc_html(get_theme_mod('adress','T23 Luwum Street, kAMPALA 5322, UGANDA')); ?></address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855"><?php echo esc_html(get_theme_mod('phonenumber','+243 80 64 12 760')); ?></a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="mailto:info@example.com"><?php bloginfo('admin_email'); ?></a></p>
            </div>
          </div>

        </div>
      </div>

      <div class="container mb-4">
          <?php if(get_theme_mod('map_location', 'map location') != '') : ?>                 
          <iframe src="<?php echo esc_html(get_theme_mod('map_location','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7979.517991059905!2d32.575415660588604!3d0.31244947406201395!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbc80d7fb7785%3A0x2a1b3c7bc0ee0b6d!2sNamaganda%20Plaza!5e0!3m2!1sen!2sug!4v1566840125782!5m2!1sen!2sug')); ?>" width="100%" height="380" frameborder="0" style="border:0" allowfullscreen></iframe>                  
         <?php endif; ?> 
      </div>
      
     <?php if(is_active_sidebar('sidebar-widgets-contact_form')) : ?>
      <div class="container">
        <div class="form">   
		     <?php dynamic_sidebar('sidebar-widgets-contact_form'); ?>	 
        </div>
      </div>
      <?php endif;?>
      
    </section><!-- #contact -->

  </main>
<!--========================== Footer ============================-->
  <footer id="footer">
    <div class="footer-top bgcolour">
      <div class="container">
        <div class="row">

             <?php if(is_active_sidebar('sidebar-widgets-footer-info')) : ?>
		     <?php dynamic_sidebar('sidebar-widgets-footer-info'); ?>
			 <?php endif; ?>
             
             <?php if(is_active_sidebar('sidebar-widgets-footer-links')) : ?>
		     <?php dynamic_sidebar('sidebar-widgets-footer-links'); ?>
			 <?php endif; ?>


          <div class="col-lg-3 col-md-6 footer-contact">
          
            <?php if(is_active_sidebar('sidebar-widgets-footer-contact')) : ?>
		    <?php dynamic_sidebar('sidebar-widgets-footer-contact'); ?>
			<?php endif; ?>

            <div class="social-links">
              
              <?php if(get_theme_mod('twitter_url', 'http://twitter.com') != '') : ?>
                    <a class="twitter" href="<?php echo esc_url(get_theme_mod('twitter_url','http://twitter.com')); ?>" target="_blank"><i class="fa fa-twitter"></i> </a>
                    <?php endif; ?>
                    <?php if(get_theme_mod('facebook_url', 'http://facebook.com') != '') : ?>
                    <a class="facebook" href="<?php echo esc_url(get_theme_mod('facebook_url','http://facebook.com')); ?>" target="_blank"><i class="fa fa-facebook"></i> </a>
                    <?php endif; ?>

                    <?php if(get_theme_mod('linkedin_url', 'http://linkedin.com') != '') : ?>
                    <a class="linkedin" href="<?php echo esc_url(get_theme_mod('facebook_url','http://linkedin.com')); ?>" target="_blank"><i class="fa fa-linkedin fa-fw"></i> </a>
                    <?php endif; ?>
                    <?php if(get_theme_mod('instagram_url', 'http://instagram.com') != '') : ?>
                    <a class="instagram" href="<?php echo esc_url(get_theme_mod('facebook_url','http://linkedin.com')); ?>" target="_blank"><i class="fa fa-instagram"></i> </a>
                    <?php endif; ?>
              
            </div>

          </div>

                    <?php if(is_active_sidebar('sidebar-widgets-footer-newsletter')) : ?>
		            <?php dynamic_sidebar('sidebar-widgets-footer-newsletter'); ?>
			        <?php endif; ?>
          
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <?php echo esc_html(dreamlines_copyright()); ?> <strong>
             <?php  if(get_theme_mod('Copyright', 'Company brand') != '') : ?>
               <?php  echo esc_html(get_theme_mod('Copyright','Company brand')); ?> 
             <?php  endif; ?>
        </strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a class="" href="#">WordPress</a>
      </div>
    </div>
  </footer><!-- #footer -->
  
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <?php wp_footer(); ?>

</body>
</html>
