/*-----------------------------------------------------------------------------------*/
/* Dreamlines Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name       :   Dreamlines
Theme URI        :   
Version          :   1.2
Tested up to     :   WP 5.2.2
Author           :   Henrys Kasereka
Author URI       :   
Requires at least:   4.9.6
Tested up to     :   WordPress 5.2.2
Requires PHP     :   7.0
Stable tag       :   1.2
Contributors     :   WordPress
Tags             :   flexible-header, custom-colors,custom-background,featured-images,threaded-comments,custom-menu, custom-logo,portfolio,footer-widgets, theme-options,full-width-template,editor-style
license          :   GNU General Public License v3.0
License URI      :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   hk@dreamlineshift.com

/*-----------------------------------------------------------------------------------*/
/* Changelog */
/*-----------------------------------------------------------------------------------*/

1 - 1.2

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - Bootstrap - https://getbootstrap.com
    Licensed: Under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

2 - wow.js - https://wowjs.uk/
	License: GNU GPL license v3 http://www.gnu.org/licenses/gpl.html

3 - Superfish - https://superfish.joelbirch.design/
	License:  http://www.gnu.org/licenses/gpl.html

4 - Sticky - http://stickyjs.com/
    License:  http://www.gnu.org/licenses/gpl.html

5 - Owl Carousel - https://owlcarousel2.github.io/OwlCarousel2/
    License:  https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE

6 - Magnific popup - https://dimsemenov.com/plugins/magnific-popup/
    License:  Script is MIT licensed and free and will always be kept this way.	
	
7 - Ionicons - http://ionicons.com/
    License:  Script is MIT licensed and free and will always be kept this way.	

8 - Images
	https://unsplash.com/search/photos/dubai
	https://unsplash.com/photos/Fr6zexbmjmc

9 - Social Icons
	Icons have used from Font Awesome Icons http://fortawesome.github.io/Font-Awesome/icons/
	
10 - Easing - https://cdnjs.com/libraries/jquery-easing
    License: https://github.com/gdsmith/jquery.easing/blob/master/LICENSE
	
11 - Animate.css -http://daneden.me/animate
    Licensed: Under the MIT license - http://opensource.org/licenses/MIT

Licensed under GPL. Fonts licensed under SIL OFL 1.1 http://scripts.sil.org/OFL

For any help you can mail us at support[at] hk@dreamlineshift.com