<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section 
 *
 * @package dreamlines
 */
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?> >
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <?php wp_head(); ?>
   
</head>

<body id="body" <?php body_class(); ?>>

  <!--========================== Top Bar ============================-->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container clearfix">
      <div class="contact-info float-left">
        <i class="fa fa-envelope-o"></i> <a href="#contact"><?php bloginfo('admin_email'); ?></a>
        <?php if(get_theme_mod('Phone_number', '+256 75 65 98 610') != '') : ?>
        <i class="fa fa-phone"></i>   <?php echo esc_html(get_theme_mod('Phone_number','+256 75 65 98 610')); ?> 
        <?php endif; ?>
        
      </div>
      <div class="social-links float-right">
        
                     <?php if(get_theme_mod('twitter_url', 'http://twitter.com') != '') : ?>
                    <a class="twitter" href="<?php echo esc_url(get_theme_mod('twitter_url','http://twitter.com')); ?>" target="_blank"><i class="fa fa-twitter"></i> </a>
                    <?php endif; ?>
                    <?php if(get_theme_mod('facebook_url', 'http://facebook.com') != '') : ?>
                    <a class="facebook" href="<?php echo esc_url(get_theme_mod('facebook_url','http://facebook.com')); ?>" target="_blank"><i class="fa fa-facebook"></i> </a>
                    <?php endif; ?>

                    <?php if(get_theme_mod('linkedin_url', 'http://linkedin.com') != '') : ?>
                    <a class="linkedin" href="<?php echo esc_url(get_theme_mod('facebook_url','http://linkedin.com')); ?>" target="_blank"><i class="fa fa-linkedin fa-fw"></i> </a>
                    <?php endif; ?>
                    <?php if(get_theme_mod('instagram_url', 'http://instagram.com') != '') : ?>
                    <a class="instagram" href="<?php echo esc_url(get_theme_mod('facebook_url','http://linkedin.com')); ?>" target="_blank"><i class="fa fa-instagram"></i> </a>
                    <?php endif; ?>
                    
      </div>
    </div>
  </section>

  <!--========================== Header ============================-->
  <header id="header">
    <div class="container">
      <!-- logo -->
      <div id="logo" class="pull-left">
        <h1>
        <a href="<?php echo esc_url(site_url()); ?>"> <?php if(has_custom_logo()){ the_custom_logo(); } ?></a>
        <a href="<?php echo esc_url(site_url()); ?>" class="scrollto text_title_color" > <?php bloginfo('name'); ?> <span class="hidden"><?php bloginfo('description'); ?></span></a>
        </h1>
        
      </div>
      <!-- end logo -->
      <!-- menu -->
              <?php
				  
				wp_nav_menu( array(
                                'menu'              => 'primary',
                                'theme_location'    => 'primary',
                                'depth'             => 1,
                                'container'         => 'nav',
								'container_id'      => 'nav-menu-container',
                                'menu_class'        => 'nav-menu',
                                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                'walker'            => new wp_bootstrap_navwalker())
                ); 
                
				
              ?>
      <!-- end menu -->
      
    </div>
  </header><!-- #header -->

