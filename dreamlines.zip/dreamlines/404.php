<?php get_header();

?>
<!--========================== 404 ============================-->
  <section id="intro">
       <div class="container">
            
           <div id="content">
                     <h2>Error 404 - Not Found. Contact admin <?php bloginfo('admin_email'); ?></h2>
            </div> 
            
      </div>
  </section>
<!-- #404 -->
  
  <main id="main">
  
  	<!--========================== About Section ============================-->
    <section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          
             <?php if(is_active_sidebar('sidebar-widgets-abimg')) : ?>
		     <?php dynamic_sidebar('sidebar-widgets-abimg'); ?>
			 <?php endif;?>
             <?php if(is_active_sidebar('sidebar-widgets-desc')) { ?>
		     <?php dynamic_sidebar('sidebar-widgets-desc'); ?>
			 <?php }?>
        </div>
      </div>
    </section><!-- end about -->

    <!--========================== Services Section ============================-->
    <section id="services" >
      <div class="container">
        <div class="section-header">
          <h2 class="text_title_color"><?php echo esc_html(get_theme_mod('Services','Services')); ?></h2>
          <p> <?php echo esc_html(get_theme_mod('box_description','Sed tamen tempor magna labore dolore dolor sint tempor duis magna elit veniam aliqua esse amet veniam enim export quid quid.')); ?></p>
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="box wow fadeInLeft">
              <div class="icon"><i class="fa fa-<?php echo esc_html(get_theme_mod('box1_icon','bar-chart')); ?>"></i></div>
              <h4 class="title"><a href=""><?php echo esc_url(get_theme_mod('box1_heading','Heading Service 1')); ?></a></h4>
              <p class="description"><?php echo esc_url(get_theme_mod('box1_text','Maecenas sed diam eget risus varius blandit sit amet non magna.')); ?></p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInLeft">
              <div class="icon"><i class="fa fa-<?php echo esc_html(get_theme_mod('box2_icon','book')); ?>"></i></div>
              <h4 class="title"><a href=""><?php echo esc_url(get_theme_mod('box2_heading','Heading Service 2')); ?></a></h4>
              <p class="description"><?php echo esc_html(get_theme_mod('box2_text','Maecenas sed diam eget risus varius blandit sit amet non magna.')); ?></p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInLeft">
              <div class="icon"><i class="fa fa-<?php echo esc_html(get_theme_mod('box3_icon','pie-chart')); ?>"></i></div>
              <h4 class="title"><a href=""><?php echo esc_url(get_theme_mod('box3_heading','Heading Service 2')); ?></a></h4>
              <p class="description"><?php echo esc_html(get_theme_mod('box3_text','Maecenas sed diam eget risus varius blandit sit amet non magna.')); ?></p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInLeft">
              <div class="icon"><i class="fa fa-<?php echo esc_html(get_theme_mod('box4_icon','credit-card')); ?>"></i></div>
              <h4 class="title"><a href=""><?php echo esc_url(get_theme_mod('box4_heading','Heading Service 2')); ?></a></h4>
              <p class="description"><?php echo esc_html(get_theme_mod('box4_text','Maecenas sed diam eget risus varius blandit sit amet non magna.')); ?></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- end services -->
	
	
    <!--========================== Testimonials Section ============================-->
    <section id="testimonials" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2 class="text_title_color"><?php echo esc_html(get_theme_mod('recent_news','Recent News')); ?></h2>
          <p></p>
          
        </div>
        <div class="owl-carousel testimonials-carousel">
           <?php if ( have_posts() ) : ?>
            <?php while(have_posts()) : the_post(); ?>
                 <div class="testimonial-item">
                    <?php the_post_thumbnail('news-thumb', array('class'    => 'testimonial-img')); ?>
                    
                        <h3>
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        <h5><?php the_time('F j, Y g:i a'); ?></h5>
                        <div class="excerpt">
						    <?php the_excerpt(); ?>
                            <a class="button" href="<?php the_permalink(); ?>">Read More</a>
                        </div>
                   
                 </div>
            <?php endwhile; ?>
            <?php echo  esc_html(the_posts_navigation()); ?>
          <?php endif;?>
        </div>

      </div>
    </section><!-- End testimonials -->
    
<?php get_footer();?>