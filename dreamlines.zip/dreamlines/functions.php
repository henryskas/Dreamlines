<?php
    /**
    * Dreamlines functions and definitions
    *
    * @link https://dreamlines.com
    *
    * @package dreamlines
    */
    // Register Custom Navigation Walker
    require_once('inc/wp_bootstrap_navwalker.php');
    // Setup theme setting
if ( ! function_exists( 'dreamlines_setup' ) ) :
function dreamlines_setup() {
    /*
    * Make theme available for translation.
    * Translations can be filed in the /languages/ directory.
    * If you're building a theme based on dreamline, use a find and replace
    * to change dreamlines to the name of your theme in all the template files.
    */
    load_theme_textdomain( 'dreamlines', get_template_directory() . '/languages' );
    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );
    // Featured Image Support
    add_theme_support('post-thumbnails');
    add_image_size('news-thumb', 400, 200);
    add_image_size('news-thumb-large', 1000, 400);
    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-background', array(
        'default-color' => 'ffffff'
    ) );
    add_editor_style( 'editor-style.css' );
    // Post Format Support
    add_theme_support('post-formats', array('aside', 'gallery', 'link'));
    // customer logo
    add_theme_support( 'custom-logo', array(
        'height'      => 40,
        'width'       => 40,
        'flex-width' => true,
    ) );
    if ( ! isset( $content_width ) ) {
    $content_width = 900;
    }
    // Add theme support for Custom Logo.
    add_theme_support('custom-header', apply_filters('dreamlines_custom_header_args', array(
        'default-image'    => '',
    'default-text-color' => 'fff',
    'width' => 1920,
    'height' => 900,
    'flex-height' => true,
    'header_text' =>true,       
    )));
    // Featured Image Support

    set_post_thumbnail_size(900, 600);

    // Post Format Support
    add_theme_support('post-formats', array('gallery'));

    // Nav Menus
    register_nav_menus(array(
        'primary'	=> esc_html__('Primary Menu','dreamlines'),
        'footer'	=> esc_html__('Footer Menu','dreamlines')
    ));

}
endif;
    add_action('after_setup_theme','dreamlines_setup');
    /**
    * Set the content width in pixels, based on the theme's design and stylesheet.
    *
    * Priority 0 to make it available to lower priority callbacks.
    *
    * @global int $dreamlines_content_width
    */
function dreamlines_content_width() {
    // This variable is intended to be overruled from themes.
    // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    $GLOBALS['dreamlines_content_width'] = apply_filters( 'dreamlines_content_width', 640 );
}
    add_action( 'after_setup_theme', 'dreamlines_content_width', 0 );

    // protect WordPress
function dreamlines_WordPress_errors(){ 
    return 'Something went wrong!'; 
} 

    add_filter( 'login_errors', 'dreamlines_WordPress_errors' );
    // Excerpt Length
function dreamlines_set_excerpt_length(){
        return 80;
}

    add_filter('excerpt_length','dreamlines_set_excerpt_length');

    //script and style enqueues here
function dreamlines_enqueues(){
    //css
    wp_enqueue_style("dreamlines-fonts', '//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800|Montserrat:300,400,700");
    wp_enqueue_style("dreamlines-parent", esc_url( get_template_directory_uri()).'/style.css' );
    wp_enqueue_style("bootstrap",esc_url( get_template_directory_uri())."/lib/bootstrap/css/bootstrap.min.css");
    wp_enqueue_style("font-awesome",esc_url( get_template_directory_uri())."/lib/font-awesome/css/font-awesome.min.css");
    wp_enqueue_style("animate",esc_url( get_template_directory_uri())."/lib/animate/animate.min.css");
    wp_enqueue_style("ionicons",esc_url( get_template_directory_uri())."/lib/ionicons/css/ionicons.min.css.css");
    wp_enqueue_style("owl-carousel",esc_url( get_template_directory_uri())."/lib/owlcarousel/assets/owl.carousel.min.css");
    wp_enqueue_style("wpstyle",esc_url( get_template_directory_uri())."/css/wpstyle.css");
    //js
    wp_enqueue_script( 'deamline_jquery', esc_url( get_template_directory_uri() ) . '/lib/jquery/jquery.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'bootstrapbundle', esc_url( get_template_directory_uri() ) . '/lib/bootstrap/js/bootstrap.bundle.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'easing', esc_url( get_template_directory_uri() ) . '/lib/easing/easing.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'wow', esc_url( get_template_directory_uri() ) . '/lib/wow/wow.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'owl', esc_url( get_template_directory_uri() ) . '/lib/owlcarousel/owl.carousel.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'magnific', esc_url( get_template_directory_uri() ) . '/lib/magnific-popup/magnific-popup.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'sticky', esc_url( get_template_directory_uri() ) . '/lib/sticky/sticky.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'main', esc_url( get_template_directory_uri() ) . '/js/main.js', array('jquery'), '20151215', true );

    if ( is_singular() ) wp_enqueue_script( "comment-reply" );
}
    add_action('wp_enqueue_scripts','dreamlines_enqueues'); 
    //Dynamic Copyright Date in WordPress Footer
function dreamlines_copyright() {
    global $wpdb;
    $dreamlines_copyright_dates = $wpdb->get_results("
    SELECT
    YEAR(max(post_date_gmt)) AS lastdate
    FROM
    $wpdb->posts
    WHERE
    post_status = 'publish'
    ");
    return $dreamlines_copyright_dates[0]->lastdate;
}
    // Add Customizer Functionality
    require get_template_directory(). '/inc/customizer.php';


